 and
 	smn_base.smn_unidades_servicios.uns_fecha_registro>=${fld:uns_fecha_registro_ini}
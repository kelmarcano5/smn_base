 and
 	upper(smn_base.smn_unidades_servicios.uns_descripcion) like upper(${fld:uns_descripcion})
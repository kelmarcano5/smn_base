 and
 	smn_base.smn_unidades_servicios.smn_areas_servicios_id=${fld:smn_areas_servicios_id}
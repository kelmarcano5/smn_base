 and
 	upper(smn_base.smn_unidades_servicios.uns_codigo) like upper(${fld:uns_codigo})
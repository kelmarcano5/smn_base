 and
 	smn_base.smn_unidades_servicios.uns_es_laboratorio like upper(${fld:uns_es_laboratorio})
 and
 	smn_base.smn_unidades_servicios.smn_tipo_unidad_administrativa like upper(${fld:smn_tipo_unidad_administrativa})
select  
      *   
from    
      smn_base.smn_areas_servicios
select
	'' as ase_codigo_pl0,
	'' as uns_codigo,
	'' as uns_descripcion,
	'' as ase_codigo_pl0_reference


INSERT INTO smn_base.smn_unidades_servicios
(
	smn_unidades_servicios_id,
	smn_areas_servicios_id,
	uns_codigo,
	uns_descripcion,
	uns_idioma,
	uns_usuario,
	uns_fecha_registro,
	uns_hora,
	smn_tipo_unidad_administrativa,
	uns_es_laboratorio
)
VALUES
(
	${seq:currval@smn_base.seq_smn_unidades_servicios},
	${fld:smn_areas_servicios_id},
	${fld:uns_codigo},
	${fld:uns_descripcion},
	'${def:locale}',
	'${def:user}',
	{d '${def:date}'},
	'${def:time}',
	${fld:smn_tipo_unidad_administrativa},
	${fld:uns_es_laboratorio}

)

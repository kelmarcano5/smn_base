select ${seq:nextval@smn_base.seq_smn_unidades_servicios} as id

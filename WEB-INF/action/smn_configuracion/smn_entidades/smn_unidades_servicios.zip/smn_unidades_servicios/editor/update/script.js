addNew();
alertBox ('${lbl:b_record_updated}', '${lbl:b_continue_button}', null, 'parent.search(); parent.closeDialog();');

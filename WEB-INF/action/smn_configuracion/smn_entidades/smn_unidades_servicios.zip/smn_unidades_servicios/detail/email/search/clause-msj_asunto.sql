 and
 	upper(smn_base.smn_mensajes.msj_asunto) like upper(${fld:msj_asunto})
select  
      *   from    
      smn_base.smn_entidades
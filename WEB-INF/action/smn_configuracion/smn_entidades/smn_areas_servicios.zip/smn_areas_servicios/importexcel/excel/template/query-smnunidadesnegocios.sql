select  
      *   from    
      smn_base.smn_unidades_negocios
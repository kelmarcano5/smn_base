select
	smn_tipos_areas_id	
from 
	smn_base.smn_tipos_areas
where
	smn_tipos_areas_id = ${fld:smn_tipos_areas_id}
	
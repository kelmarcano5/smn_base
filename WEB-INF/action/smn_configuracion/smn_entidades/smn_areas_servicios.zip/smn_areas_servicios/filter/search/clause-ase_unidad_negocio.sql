 and
 	smn_base.smn_areas_servicios.ase_unidad_negocio=${fld:ase_unidad_negocio}
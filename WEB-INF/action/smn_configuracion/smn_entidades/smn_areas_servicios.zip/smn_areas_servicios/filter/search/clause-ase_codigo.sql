 and
 	upper(smn_base.smn_areas_servicios.ase_codigo) like upper(${fld:ase_codigo})
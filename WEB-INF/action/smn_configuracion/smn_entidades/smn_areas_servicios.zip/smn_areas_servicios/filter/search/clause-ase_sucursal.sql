 and
 	smn_base.smn_areas_servicios.ase_sucursal=${fld:ase_sucursal}
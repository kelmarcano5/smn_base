 and
 	smn_base.smn_areas_servicios.ase_empresa=${fld:ase_empresa}
 and
 	upper(smn_base.smn_areas_servicios.ase_descripcion) like upper(${fld:ase_descripcion})
 and
 	smn_base.smn_areas_servicios.smn_tipos_areas_id=${fld:smn_tipos_areas_id}
addNew();
alertBox ('${lbl:b_configuration_stored}: ${fld:id}', '${lbl:b_continue_button}', null, 'setFocusOnForm("form1");');


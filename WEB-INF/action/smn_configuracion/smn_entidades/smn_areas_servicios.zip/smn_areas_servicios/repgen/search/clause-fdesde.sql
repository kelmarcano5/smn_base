 and
 	smn_base.smn_areas_servicios.ase_fecha_registro>=${fld:fdesde}

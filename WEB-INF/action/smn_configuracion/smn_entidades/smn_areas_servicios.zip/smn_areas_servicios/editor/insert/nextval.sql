select ${seq:nextval@smn_base.seq_smn_areas_servicios} as id

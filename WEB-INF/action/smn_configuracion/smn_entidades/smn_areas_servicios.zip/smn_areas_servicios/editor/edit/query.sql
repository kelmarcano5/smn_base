select	
	*
from 
	smn_base.smn_areas_servicios
where 
	smn_areas_servicios_id = ${fld:id}


